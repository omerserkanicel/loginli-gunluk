from flask import Flask, render_template,request, redirect, send_from_directory

# Importing the database library

from flask_sqlalchemy import SQLAlchemy




app = Flask(__name__)

# Connecting SQLite

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Creating a DB

db = SQLAlchemy(app)

# Creating a DB table

 

#Assignment #1. Create a DB table

class Card(db.Model):

    # Creating the fields

    #id

    id = db.Column(db.Integer, primary_key=True)

    # Title

    title = db.Column(db.String(100), nullable=False)

    # Description

    subtitle = db.Column(db.String(300), nullable=False)

    # Text

    text = db.Column(db.Text, nullable=False)

 

    # Outputting the object and its id

    def __repr__(self):

        return f'<Card {self.id}>'

# İlk sayfa
@app.route('/')
def baslangic():
    return render_template('baslangic.html')
   

# Form sonuçları 
@app.route('/index', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        # seçilen resmi almak
        
        selected_image = request.form.get('image-selector')
        
        
        # Görev #2. Metni almak
        textTop = request.form["textTop"]

        textBottom = request.form["textBottom"]  
        
         
        # Görev #3. Metnin konumunu almak
        

        # Görev #3. Metnin rengini almak
        

        return render_template('index.html', 
                               # Seçilen resmi görüntüleme
                               selected_image=selected_image, 
                               # Görev #2. Metni görüntüleme 
                               textTop=textTop,
                               textBottom=textBottom,
                               # Görev #3. Rengi görüntüleme
                                                         
                               # Görev #3. Metnin konumunu görüntüleme
                               
                               )
    else:
        # Varsayılan olarak ilk resmi görüntüleme
        return render_template('index.html', selected_image='logo1.svg')


@app.route('/static/img/<path:path>')
def serve_images(path):
    return send_from_directory('static/img', path)


class User(db.Model):
    id = db.Column(db.Integer, primary_key= True, autoincrement=True)
    email = db.Column(db.String, nullable=False)
    password = db.Column(db.String, nullable=False)









# İçerik sayfasını çalıştırma
@app.route('/login', methods=['GET','POST'])
def login():
        error = ''
        if request.method == 'POST':
            form_login = request.form['email']
            form_password = request.form['password']
            
            #Ödev #4. yetkilendirmeyi uygulamak
            kullanicilarin_bilgileri = User.query.all()

            for kullanici in kullanicilarin_bilgileri:
                if kullanici.email == form_login and kullanici.password == form_password:
                    return redirect("/günlük")
             

            return render_template('login.html')              
        else:
            return render_template('login.html')



@app.route('/reg', methods=['GET','POST'])
def reg():
    if request.method == 'POST':
        login= request.form['email']
        sifre = request.form['password']
        
        #Ödev #3 Kullanıcı verilerinin veri tabanına kaydedilmesini sağlayın
        kullanici_girdi = User(email=login, password=sifre)
        
        db.session.add(kullanici_girdi)
        db.session.commit()

        
        return redirect('/')
    
    else:    
        return render_template('registration.html')


# İçerik sayfasını çalıştırma
@app.route('/günlük')
def günlük():
    # Veri tabanı girişlerini görüntüleme
    cards = Card.query.order_by(Card.id).all()
    return render_template('günlük.html', cards=cards)

# Kayıt sayfasını çalıştırma
@app.route('/card/<int:id>')
def card(id):
    card = Card.query.get(id)

    return render_template('card.html', card=card)

# Giriş oluşturma sayfasını çalıştırma
@app.route('/create')
def create():
    return render_template('create_card.html')

# Giriş formu
@app.route('/form_create', methods=['GET','POST'])
def form_create():
    if request.method == 'POST':
        title =  request.form['title']
        subtitle =  request.form['subtitle']
        text =  request.form['text']

        # Veri tabanına gönderilecek bir nesne oluşturma
        card = Card(title=title, subtitle=subtitle, text=text)

        db.session.add(card)
        db.session.commit()
        return redirect('/günlük')
    else:
        return render_template('create_card.html')

with app.app_context():
    db.create_all()



if __name__ == "__main__":
    app.run(debug=True)
